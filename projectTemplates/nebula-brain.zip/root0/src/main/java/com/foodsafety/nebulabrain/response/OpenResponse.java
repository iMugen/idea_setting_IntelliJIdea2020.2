package ${IJ_BASE_PACKAGE};

import com.foodsafety.common.response.ResponseHandler;

public enum OpenResponse implements ResponseHandler {
    ;

    private Integer code;

    private String description;

    OpenResponse(Integer code, String description) {
        this.code = code;
        this.description = description;
    }

    @Override
    public Integer getCode() {
        return this.code;
    }

    @Override
    public String getDescription() {
        return this.description;
    }
}
